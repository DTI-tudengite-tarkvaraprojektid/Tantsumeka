<?php header("HTTP/1.0 404 Not Found");exit;?>
db-pass=5QstxcP636C6F29PE